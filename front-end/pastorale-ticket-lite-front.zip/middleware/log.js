export default function (context) {
  console.log('[Middleware] The Log Middleware is running')
}
