
<template>
  <div>
  	<center><h1>This is screen select ticket</h1></center>
 </div>
</template>
<style scoped>
</style>
<script src="@@/business/selectticket/Selectticket.js">

