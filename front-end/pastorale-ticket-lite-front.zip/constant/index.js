import router from '@/constant/router';
import api from '@/constant/api';

export default {
	router,
	api
}
