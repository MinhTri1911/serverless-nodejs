const SELECT_TICKET = 'selectticket';

export default {
	SELECT_TICKET
}
