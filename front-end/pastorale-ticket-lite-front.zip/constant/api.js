const GET_LIST_CITY = 'init-page';
const SEARCH_POST_CODE = 'search-post-code';

export default {
  GET_LIST_CITY,
  SEARCH_POST_CODE
}
