<template>

  <!-- Mobile Menu Responsive -->
  <section id="Drawer">
    <header>
      <section>
        <a class="menu-trigger" href="#">
          <span></span>
          <span></span>
          <span></span>
        </a>
      </section>
      <nav id="mobile-nav">
        <ul>
          <li class="tmenu"><a href="#">ご利用ガイド</a></li>
          <li class="tmenu"><a href="#">公演一覧</a></li>
          <li class="tmenu"><a href="#">利用登録</a></li>
          <li class="tlogin"><a href="login.html">&nbsp;ログイン</a></li>
          <li class="tmenu"><a href="#">公演検索</a></li>
          <li class="tmenu"><a href="#">よくあるご質問（FAQ）</a></li>
        </ul>
      </nav>
    </header>
  </section>
  <!-- Mobile Menu Responsive -->

</template>



