<template>
  <dl id="Info">
    <dt>2018.8.1</dt>
    <dd><a href="#">{{ $t('common.home.title') }}</a><span class="new"><img src="@/assets/images/icon_info_new.gif" alt="new" width="50" height="20"></span></dd>
    <dt>2018.7.31</dt>
    <dd><a href="#">○○○○コンサートのアーティスト入院による公演延期のお知らせ。</a></dd>
    <dt>2018.5.18</dt>
    <dd><a href="#">○○○○公演中止による払い戻しについて。ダミーテキストダミーテキストダミーテキストダミーテキストダミーテキストダミーテキストダミーテキストダミーテキスト</a></dd>
    <dt>2018.3.20</dt>
    <dd><a href="#">○○○○コンサートのアーティスト入院による公演延期のお知らせ。</a></dd>
    <dt>2017.12.24</dt>
    <dd><a href="#">○○○○公演中止による払い戻しについて。</a></dd>
  </dl>
</template>

<script>
  export default {
    name: "ItemNotify"
  }
</script>

<style scoped>

</style>
