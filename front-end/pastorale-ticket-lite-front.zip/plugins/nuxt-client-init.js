export default async (ctx) => {
  await ctx.store.dispatch('post/nuxtClientInit', ctx)
}