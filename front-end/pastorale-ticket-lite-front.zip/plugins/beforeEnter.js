import constant from '../constant';
export default function ({ store, route, redirect }) {

    
}

