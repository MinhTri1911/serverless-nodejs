if (process.BROWSER_BUILD) {
    require("bootstrap");
}