export default {
    authenticated: false,
    user: '',
}