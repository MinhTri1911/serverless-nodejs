export default {
    loadedPosts: [],
    loadedPost: [],
    counter: 0
}