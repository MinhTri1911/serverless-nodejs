import state from './state'

export default {
    // loadedPosts: (state) => {
    //     return state.loadedPosts
    // }
}