export const SET_POST = 'SET_POST'
export const ADD_POST = 'ADD_POST'
export const EDIT_POST = 'EDIT_POST'
export const increment = 'increment'
export const decrement = 'decrement'

export default {
    SET_POST,
    ADD_POST,
    EDIT_POST,
  increment,
  decrement
}