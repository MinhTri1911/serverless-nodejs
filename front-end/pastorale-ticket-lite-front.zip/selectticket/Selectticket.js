import axios from 'axios'
import { mapActions } from 'vuex'
export default {
  name: 'Selectticket',
  layout: 'default',
  middleware: 'guest',
}
