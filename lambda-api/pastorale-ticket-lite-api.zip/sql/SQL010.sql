select
    case
    when count(*) = 1
        then '1'
    else '0'
    end as macth_flg
from
    m_member
where
    client_id = $client_id
    and member_id = $code
    and replace (replace (member_nm, ' ', ''), '@', '') = replace (replace (/* member_nm */null, ' ', ''), '@', '')
    and replace (replace (member_kn, ' ', ''), '@', '') = replace (replace (/* member_kn */null, ' ', ''), '@', '')
/*%if form.tel_no != "" and form.mobile_no != "" */
    and (
    replace (tel_no, '-', '') = replace (/* tel_no */null, '-', '')
    or replace (mobile_no, '-', '') = replace (/* mobile_no */null, '-', '')
    )
/*%end*/
/*%if form.tel_no != "" and form.mobile_no == "" */
    and replace (tel_no, '-', '') = replace (/* tel_no */null, '-', '')
/*%end*/
/*%if form.tel_no == "" and form.mobile_no != "" */
    and replace (mobile_no, '-', '') = replace (/* mobile_no */null, '-', '')
/*%end*/
    and mail_address = ''
    and member_pass = ''
    and admission_kb = '1'
    and (black_cd = '' or black_cd = '0')
