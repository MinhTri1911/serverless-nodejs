# 本番環境のデプロイ手順

## デプロイ手順

```
# レポジトリを取得する
git clone https://xxxxx
cd xxxxx
git checkout master
```
