const Timeout = {
  JWT_EXPIRATION_TIME: '10080m'
}

export default Timeout;
